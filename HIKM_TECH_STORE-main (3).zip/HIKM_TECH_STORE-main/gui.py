import tkinter as tk
from tkinter import messagebox

from chatbot import understand_customer
from products import show_products
from calculator import calculate
from whatsapp_sender import send_order


# ==============================
import tkinter as tk
from tkinter import messagebox

from chatbot import understand_customer
from products import show_products
from calculator import calculate
from whatsapp_sender import send_order


window = tk.Tk()

window.title(
    "HIKM Tech Store Assistant"
)

window.geometry(
    "600x700"
)

window.config(
    bg="#111827"
)


current_products = []

selected_product = ""

selected_price = 0


chat_box = tk.Text(

    window,
    width=65,
    height=20,
    bg="#1f2937",
    fg="white",
    font=("Arial",12)

)

chat_box.pack(
    pady=20
)



def send_message():


    global current_products


    user_text = user_input.get().lower()


    chat_box.insert(

        tk.END,

        "\nCustomer: "
        + user_text

    )


    category = understand_customer(

        user_text

    )


    if category:


        products = show_products(

            category

        )


        current_products = products


        reply = "\n\nBot: Recommended Products\n"


        number = 1


        for item in products:


            reply += (

                str(number)

                + ". "

                + item[0]

                + " - ₦"

                + format(
                    item[1],
                    ","
                )

                + "\n"

            )


            number += 1



        chat_box.insert(

            tk.END,

            reply

        )


    else:


        chat_box.insert(

            tk.END,

            "\nBot: Sorry I don't understand"

        )


    user_input.delete(
        0,
        tk.END
    )



def select_product():


    global selected_product
    global selected_price


    try:


        choice = int(

            product_entry.get()

        )


        item = current_products[choice-1]


        selected_product = item[0]

        selected_price = item[1]


        chat_box.insert(

            tk.END,

            f"""

Bot: You selected

{selected_product}

"""

        )



    except:


        messagebox.showerror(

            "Error",

            "Invalid Product"

        )



def place_order():


    quantity = int(

        quantity_entry.get()

    )


    total = calculate(

        selected_price,

        quantity

    )


    summary=f"""

ORDER SUMMARY


Product:
{selected_product}


Quantity:
{quantity}


Total:
₦{format(total,",")}


"""


    confirm = messagebox.askyesno(

        "Confirm Order",

        summary

    )



    if confirm:


        send_order(

            "Customer",

            "Not Provided",

            selected_product,

            quantity,

            total

        )


        messagebox.showinfo(

            "Success",

            "Order Sent Successfully"

        )



user_input = tk.Entry(

    window,

    width=40,

    font=("Arial",14)

)


user_input.pack(
    pady=10
)



send_btn=tk.Button(

    window,

    text="Send Message",

    command=send_message,

    width=20

)


send_btn.pack()



product_entry=tk.Entry(

    window,

    width=20

)

product_entry.pack(
    pady=10
)


select_btn=tk.Button(

    window,

    text="Select Product",

    command=select_product

)

select_btn.pack()



quantity_entry=tk.Entry(

    window,

    width=20

)

quantity_entry.pack(
    pady=10
)


order_btn=tk.Button(

    window,

    text="Place Order",

    command=place_order,

    bg="green",
    fg="white"

)


order_btn.pack(
    pady=20
)



chat_box.insert(

    tk.END,

"""

Bot: Welcome to Smart Tech Store

I am your virtual sales assistant.

Tell me what you need.

Examples:
- gaming laptop
- cheap phone
- apple products


"""

)



window.mainloop()