from chatbot import Chatbot
from products import Catalog
from calculator import Calculator
from validation import Validator
from whatsapp_sender import WhatsappSender


def run():
    bot = Chatbot()
    catalog = Catalog()
    calc = Calculator()
    validator = Validator()
    sender = WhatsappSender()

    bot.welcome()

    while True:
        message = input("\nCustomer: ").lower()

        category = bot.understand_customer(message)

        if category is None:
            print("Bot: Sorry I don't understand")
            continue

        products = catalog.show_products(category)
        if not products:
            continue

        choice = validator.get_choice(len(products))
        selected_product = products[choice - 1]

        product_name = selected_product.name
        price = selected_product.price

        quantity = validator.get_quantity()

        total = calc.calculate(price, quantity)

        print("\nORDER SUMMARY")
        print(product_name)
        print("Total", calc.format_currency(total))

        while True:
            confirm = input("Confirm yes/no: ").lower()
            if confirm == "yes":
                break
            elif confirm == "no":
                print("Order cancelled")
                break
            else:
                print("Invalid input")

        if confirm != "yes":
            continue

        name = input("Your name: ")
        number = input("Your phone: ")

        sent = sender.send_order(name, number, product_name, quantity, total)
        if sent:
            print("Order Sent Successfully")
        else:
            print("Order processed locally (not sent).")


if __name__ == "__main__":
    run()
