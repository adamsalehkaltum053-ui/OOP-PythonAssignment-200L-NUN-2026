

class Validator:
    @staticmethod
    def get_choice(limit: int) -> int:
        while True:
            try:
                choice = int(input("\nChoose Product: "))
                if 1 <= choice <= limit:
                    return choice
                else:
                    print("Invalid option")
            except ValueError:
                print("Numbers only")

    @staticmethod
    def get_quantity() -> int:
        while True:
            try:
                qty = int(input("Quantity: "))
                if qty > 0:
                    return qty
                print("Enter a positive number")
            except ValueError:
                print("Numbers only")