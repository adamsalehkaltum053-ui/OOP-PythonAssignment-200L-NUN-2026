
class Chatbot:
    def __init__(self, name: str = "HIKM TECH STORE"):
        self.name = name
        # keyword mapping to categories
        self.intent_map = {
            "gaming": ["gaming", "game", "gamer", "play"],
            "student": ["student", "study", "school", "college", "university"],
            "cheap": ["cheap", "budget", "affordable", "low"] ,
            "apple": ["apple", "iphone", "macbook", "airpods"],
            "phone": ["phone", "mobile", "android", "samsung", "xiaomi", "tecno", "infinix"],
            "laptop": ["laptop", "notebook", "macbook", "dell", "hp", "lenovo"],
            "accessories": ["accessory", "accessories", "mouse", "keyboard", "headset"],
            "wearables": ["watch", "band", "wearable", "fitbit"],
        }

    def welcome(self):
        print("===============================")
        print(self.name)
        print("Virtual Sales Assistant")
        print("===============================")
        print("\nBot: Welcome Customer")
        print("Bot: I can help you find gadgets. Try: 'gaming', 'student', 'cheap', 'apple', 'phone', 'laptop'")

    def understand_customer(self, message: str):
        msg = message.lower()
        for category, keywords in self.intent_map.items():
            for kw in keywords:
                if kw in msg:
                    return category

        # additional heuristics
        if "recommend" in msg or "suggest" in msg:
            return "gaming"

        return None
        
