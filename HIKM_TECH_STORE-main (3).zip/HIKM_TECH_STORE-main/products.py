

class Product:
    def __init__(self, name: str, price: int, sku: str = None, desc: str = ""):
        self.name = name
        self.price = price
        self.sku = sku
        self.desc = desc

    def __repr__(self):
        return f"Product({self.name!r}, {self.price})"


class Catalog:
    def __init__(self):
        # expanded product catalog
        self.products = {
            "gaming": [
                Product("HP Victus", 950000),
                Product("Lenovo Legion Pro 5", 1200000),
                Product("Dell Alienware m16", 1500000),
                Product("Asus ROG Strix G16", 1400000),
            ],
            "student": [
                Product("MacBook Air", 1000000),
                Product("Lenovo IdeaPad Slim 5", 850000),
                Product("Huawei MateBook D15", 700000),
                Product("Acer Swift 3", 650000),
            ],
            "cheap": [
                Product("Tecno Spark 20", 180000),
                Product("Infinix Hot 40", 220000),
                Product("Redmi Note 13 Pro", 300000),
                Product("itel A78", 110000),
            ],
            "apple": [
                Product("iPhone 16", 1300000),
                Product("MacBook Pro", 1500000),
                Product("AirPods Pro 2", 350000),
                Product("Apple Watch Series 9", 400000),
            ],
            "phone": [
                Product("Samsung Galaxy S24", 1200000),
                Product("iPhone 15", 1100000),
                Product("Xiaomi 14", 450000),
            ],
            "laptop": [
                Product("Dell XPS 13", 1050000),
                Product("HP Envy", 800000),
                Product("Asus VivoBook", 550000),
            ],
            "accessories": [
                Product("Wireless Mouse", 7000),
                Product("Mechanical Keyboard", 25000),
                Product("USB-C Hub", 8000),
            ],
            "wearables": [
                Product("Fitbit Charge 6", 90000),
                Product("Samsung Galaxy Watch 6", 200000),
            ],
        }

    def show_products(self, category: str):
        items = self.products.get(category, [])
        print("\nBot: Recommended Products:")
        if not items:
            print("Bot: No items found for that category")
            return []

        for i, item in enumerate(items, start=1):
            print(i, item.name, "- ₦", format(item.price, ","))

        return items

    def all_categories(self):
        return list(self.products.keys())
