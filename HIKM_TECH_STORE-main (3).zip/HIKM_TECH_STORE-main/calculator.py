

class Calculator:
    @staticmethod
    def calculate(price: int, quantity: int) -> int:
        return price * quantity


    @staticmethod
    def format_currency(amount: int) -> str:
        return f"₦{format(amount, ',')}"