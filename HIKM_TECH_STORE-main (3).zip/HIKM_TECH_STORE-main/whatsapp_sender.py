try:
    import pywhatkit
except Exception:
    pywhatkit = None


class WhatsappSender:
    def __init__(self, store_number: str = "+2348168182084"):
        self.store = store_number

    def send_order(self, name: str, phone_number: str, product: str, quantity: int, total: int):
        message = f"""

HIKM TECH STORE ORDER


Customer: {name}

Phone: {phone_number}


Product: {product}

Quantity: {quantity}


Total: ₦{format(total, ",")}

"""

        if pywhatkit is None:
            print("\n[Info] pywhatkit not available — printing order instead of sending.")
            print(message)
            return False

        try:
            pywhatkit.sendwhatmsg_instantly(self.store, message, wait_time=15, tab_close=True)
            return True
        except Exception as e:
            print("Failed to send via WhatsApp:", e)
            return False